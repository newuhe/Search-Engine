#encoding:UTF-8
#!-*-coding:utf-8-*-
import urllib.request
 
url = "http://www.baidu.com"
data = urllib.request.urlopen(url).read()
data = data.decode(encoding='UTF-8')
print(data.encode("GBK"))
